<?php include"varRutas.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?=IMG?>ico.png">
    <title>EM Cleaning</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?=CSS?>bootstrap.min.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?=CSS?>modern-business.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:600italic,400,800,700,300' rel='stylesheet' type='text/css'>
    <link href="<?=CSS?>font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="<?=CSS?>responsive-slider.css" rel="stylesheet">
    <link rel="stylesheet" href="<?=CSS?>animate.min.css">
    <link href="<?=CSS?>styles.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="ir-arriba hvr-sweep-to-top" style="display: block;"><i class="fa fa-angle-up fa-2x" aria-hidden="true"></i></div>


