        <!-- Footer widget -->
        <footer style="background-color: rgba(42, 39, 39, 0.61);">
            <div class="container">
                <div class="col-md-4">
                    <h4 class="t-fw">Item 1</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus saepe, quidem laudantium maiores tenetur deserunt quae porro in, autem error ab? Et provident fuga cumque accusamus, esse excepturi quia adipisci.</p>
                </div>
                <div class="col-md-4">
                    <h4 class="t-fw">Item 2</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus saepe, quidem laudantium maiores tenetur deserunt quae porro in, autem error ab? Et provident fuga cumque accusamus, esse excepturi quia adipisci.</p>
                </div>
                <div class="col-md-4">
                    <h4 class="t-fw">Item 1</h4>
                    <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fmasonideas%2F&tabs=timeline&width=350&height=350&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="280" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
                </div>
            </div>
        </footer>
         <!-- Footer copy-->
        <footer>
            <div class="container">
                <div class="col-lg-12">
                    <p>Design & Development by: <a href="http://amwebpro.com/"> AM Web Pro Inc</a></p>
                </div>
            </div>
        </footer>