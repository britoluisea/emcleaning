<?php
if( FILE_PATH ==   URL_INDEX  )
{
  include ("slider_index.php");
}
else //header de pages internas
{
  include("header-pages.php");
}
//echo FILE_PATH ." ==  ". URL_INDEX;
?>