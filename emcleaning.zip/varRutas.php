<?php
define('URL_INDEX', '/emcleaning/index.php');
define('FILE_PATH', $_SERVER['PHP_SELF']);
define('USERFILES', 'userfiles/');
define('IMG', USERFILES.'img/');
define('JS', USERFILES.'js/');
define('CSS', USERFILES.'css/');