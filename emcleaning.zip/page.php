<?php include"head.php"; ?>
<?php include"nav.php"; ?>
<?php include"header.php"; ?>
  <!--OUR MISSION -->
  <section id="our-mission" >
    <div class="container">
            <div class="col-md-12">

                <h1 class="page-header">
                    About Us
                </h1>
                <h4 class="text-description">
                 To ensure long-term client relationships through the design and management of comprehensive energy procurement strategies that exceed customer expectations by communicating market knowledge, leveraging supplier relationships, identifying unique product options, and implementing innovative solutions.
                </h4>
              <div class="col-md-6">
                <h4 class="text-description">
                 To ensure long-term client relationships through the design and management of comprehensive energy procurement strategies that exceed customer expectations by communicating market knowledge, leveraging supplier relationships, identifying unique product options, and implementing innovative solutions.
                </h4>
              </div>
              <div class="col-md-6">
                <h4 class="text-description">
                 To ensure long-term client relationships through the design and management of comprehensive energy procurement strategies that exceed customer expectations by communicating market knowledge, leveraging supplier relationships, identifying unique product options, and implementing innovative solutions.
                </h4>
              </div>
            </div>
    </div>
  </section>

<?php include"food.php"; ?> 